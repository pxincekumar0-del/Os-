package com.example.androidlauncher.ui

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.androidlauncher.data.LauncherApp
import com.example.androidlauncher.data.LauncherRepository
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class Screen { Home, Apps, Settings }

@Composable
fun LauncherApp() {
    val context = LocalContext.current
    val repo = remember { LauncherRepository(context.applicationContext) }
    var apps by remember { mutableStateOf<List<LauncherApp>>(emptyList()) }
    var screen by remember { mutableStateOf(Screen.Home) }
    var query by remember { mutableStateOf("") }

    LaunchedEffect(Unit) { apps = repo.loadApps() }

    val filtered = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query, true) }
    }

    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = {
            NavigationBar(tonalElevation = 0.dp) {
                NavigationBarItem(screen == Screen.Home, { screen = Screen.Home }, icon = { Text("⌂") }, label = { Text("Home") })
                NavigationBarItem(screen == Screen.Apps, { screen = Screen.Apps }, icon = { Text("▦") }, label = { Text("Apps") })
                NavigationBarItem(screen == Screen.Settings, { screen = Screen.Settings }, icon = { Text("⚙") }, label = { Text("Settings") })
            }
        }
    ) { padding ->
        AnimatedContent(
            targetState = screen,
            modifier = Modifier.padding(padding).fillMaxSize(),
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "navigation"
        ) { current ->
            when (current) {
                Screen.Home -> HomeScreen(apps.take(8), repo, onApps = { screen = Screen.Apps })
                Screen.Apps -> AppsScreen(filtered, query, { query = it }, repo)
                Screen.Settings -> SettingsScreen(context)
            }
        }
    }
}

@Composable
private fun HomeScreen(apps: List<LauncherApp>, repo: LauncherRepository, onApps: () -> Unit) {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(1000) } }
    val time = remember(now) { SimpleDateFormat("HH:mm", Locale.getDefault()).format(now) }
    val date = remember(now) { SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now) }
    val context = LocalContext.current

    Column(
        Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Good day", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Medium)
        GlassCard {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(time, style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Light)
                Text(date, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Text("Android Launcher", style = MaterialTheme.typography.bodyLarge)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            QuickAction("Wallpaper", Modifier.weight(1f)) {
                context.startActivity(Intent(WallpaperManagerCompat.ACTION_CHANGE_LIVE_WALLPAPER).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            QuickAction("Home app", Modifier.weight(1f)) { requestDefaultHome(context) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Your apps", style = MaterialTheme.typography.titleLarge)
            TextButton(onClick = onApps) { Text("See all") }
        }
        AppGrid(apps, repo)
    }
}

@Composable
private fun AppsScreen(apps: List<LauncherApp>, query: String, onQuery: (String) -> Unit, repo: LauncherRepository) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Apps", style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(
            value = query,
            onValueChange = onQuery,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(24.dp),
            placeholder = { Text("Search apps") }
        )
        if (apps.isEmpty()) Text("No matching apps") else AppGrid(apps, repo)
    }
}

@Composable
private fun SettingsScreen(context: Context) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium)
        GlassCard { SettingRow("Default home app", "Choose this launcher as Home") { requestDefaultHome(context) } }
        GlassCard { SettingRow("Wallpaper", "System wallpaper settings") { context.startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) } }
        GlassCard { SettingRow("App info", "Permissions and Android settings") { context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))) } }
        GlassCard { SettingRow("About", "AndroidLauncher 1.0.0") {} }
    }
}

@Composable
private fun SettingRow(title: String, subtitle: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, style = MaterialTheme.typography.titleMedium); Text(subtitle, style = MaterialTheme.typography.bodyMedium) }
        Text("›", style = MaterialTheme.typography.headlineSmall)
    }
}

@Composable
private fun QuickAction(label: String, modifier: Modifier, onClick: () -> Unit) {
    Surface(modifier.clip(RoundedCornerShape(22.dp)).clickable(onClick = onClick), tonalElevation = 2.dp, shape = RoundedCornerShape(22.dp)) {
        Text(label, Modifier.padding(16.dp), style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
private fun AppGrid(apps: List<LauncherApp>, repo: LauncherRepository) {
    LazyVerticalGrid(columns = GridCells.Adaptive(minSize = 82.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(apps, key = { it.packageName }) { app ->
            AppItem(app) { repo.launch(app) }
        }
    }
}

@Composable
private fun AppItem(app: LauncherApp, onClick: () -> Unit) {
    Column(Modifier.clip(RoundedCornerShape(22.dp)).clickable(onClick = onClick).padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Surface(Modifier.size(60.dp), shape = RoundedCornerShape(18.dp), tonalElevation = 3.dp) {
            Box(contentAlignment = Alignment.Center) { DrawableIcon(app.icon) }
        }
        Text(app.label, modifier = Modifier.padding(top = 6.dp), maxLines = 1, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun DrawableIcon(drawable: Drawable) {
    val bitmap = remember(drawable) { drawable.toBitmap(96) }
    Image(bitmap.asImageBitmap(), contentDescription = null, modifier = Modifier.size(42.dp))
}

private fun Drawable.toBitmap(size: Int): Bitmap {
    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    setBounds(0, 0, size, size)
    draw(canvas)
    return bitmap
}

@Composable
private fun GlassCard(content: @Composable () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.88f)), elevation = CardDefaults.cardElevation(0.dp)) { content() }
}

private fun requestDefaultHome(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val roleManager = context.getSystemService(RoleManager::class.java)
        if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_HOME) && !roleManager.isRoleHeld(RoleManager.ROLE_HOME)) {
            context.startActivity(roleManager.createRequestRoleIntent(RoleManager.ROLE_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
    }
    context.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

private object WallpaperManagerCompat {
    const val ACTION_CHANGE_LIVE_WALLPAPER = "android.service.wallpaper.LIVE_WALLPAPER_CHOOSER"
}
